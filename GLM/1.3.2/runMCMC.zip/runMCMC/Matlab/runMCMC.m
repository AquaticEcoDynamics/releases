function runMCMC(conf_file)
%Uses MCMC toolbox to optimise physical parameter set for General Lake
%Model (GLM)
%
%The program returns best-fit values for the parameters glm_nml(1:num_params)
%using the Markov Chain Monte Carlo method of optimisation
%
% Uses:
%     runGLMModelFit.m
%
%Writen by L Bruce 22 April 2013


%Add all necessary files in the currently directory
%start counting run time
tic;

disp_message('private/intro.txt');

set(0,'DefaultAxesFontName', 'Helvetica');
set(0,'DefaultAxesFontSize', 6);

% Change default text fonts.
set(0,'DefaultTextFontname', 'Helvetica');
set(0,'DefaultTextFontSize', 8);


conf = read_nml_file(conf_file);

remote = conf.config.remote;


base_dir = conf.paths.base_dir;

%Variable name
varname = conf.config.varname;

%Information on field data
fld_temp_file = [base_dir,conf.paths.fld_temp_file];

%List of data subsets to calculate sensitivity to
Data_Subsets = conf.dataset.Data_Subsets;
%List of measures of model fit
Model_Fit = conf.dataset.Model_Fit;

%Some information for ssh connection
paths = conf.paths;


%First read in and plot field data
fld_data = readLAwtr(fld_temp_file);
%Save plot of field temperature into Field file
%xlim([datenum('1997-02-01 00:00:00') datenum('1997-02-01 00:00:00')+760])
fig_name = [paths.base_dir,'Field/Field_Temp','.png'];
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
set(gcf,'paperposition',[0.1  0.1 15 8]);
print(gcf,'-dpng',fig_name,'-opengl');

close(gcf);

%INITIAL RUN-------------------------------------------------------------%

%List of parameters and their initial values
pars = fieldnames(conf.params);
for i = 1:length(pars)
    params{i} = {pars{i},conf.params.(pars{i})};
end

theta_initial = zeros(length(params),1);
for param_i = 1:length(params)
    theta_initial(param_i) = params{param_i}{2};
end

%Calculate GLM model fit parameters using initial run
%And save results
fit_params_init = runGLMModelFit(theta_initial,fld_data,params,paths,'init',0);

if ~exist([paths.base_dir,'Results/Plots_Ini/'],'dir')
    mkdir([paths.base_dir,'Results/Plots_Ini/']);
end
if ~exist([paths.base_dir,'Results/Plots_Opt'],'dir')
    mkdir([paths.base_dir,'Results/Plots_Opt']);
end
% if ~exist([paths.base_dir,'Results/Plots'],'dir')
%     mkdir([paths.base_dir,'Results/Plots']);
% end    

%Plot initial run and comparison against field - save results
plotLake
xlim([sim_start sim_stop]);
%x_tick = [sim_start:round((sim_start-sim_stop)/4):sim_stop];
x_tick_i = get(gca,'XTick');
x_tick = sim_start:(sim_stop - sim_start)/4:sim_stop;
set(gca,'XTick',x_tick,'XTickLabel',datestr(x_tick,'mm-yy'))

ylim([0 max_depth_plots])
fig_name = [paths.base_dir,'Results/Plots_Ini/Sim_Temp','.png'];
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
set(gcf,'paperposition',[0  0 15 8]);
print(gcf,'-dpng',fig_name,'-opengl');

%Now read in and plot field data
%Plot LDS output
figure
varInformation
pcolor(fld_data.time,fld_data.depth,fld_data.temp');
 axis ij
shading interp
%Save plot of field temperature into Field file
xlim([sim_start sim_stop]);

x_tick = sim_start:(sim_stop - sim_start)/4:sim_stop;

set(gca,'XTick',x_tick,'XTickLabel',datestr(x_tick,'mm-yy'))

ylim([0 max_depth_plots])

 xlabel('Date')
 ylabel('Depth (m)')
var_lim = varIndex.temp.caxis;
var_title = varIndex.temp.title;
 title(var_title)
 caxis(var_lim)
 colorbar

fig_name = [paths.base_dir,'Results/Plots_Ini/Field_Temp','.png'];
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
set(gcf,'paperposition',[0  0 15 8]);
print(gcf,'-dpng',fig_name,'-opengl');

%Now plot scatter and time series comparisons

fitparams = calcGLMModelFit(fld_data,[paths.base_dir,'Output/output_init.nc'],'temp','true',paths,'Plots_Ini/');

%Renames Plots folder to Ini_Plots folder
%copyfile([paths.base_dir,'Results/Plots'],[paths.base_dir,'Results/Plots_Ini'])


close all;

% ---------------------------- RESULTS FILE --------------------------- %

% Create .csv file.
fid = fopen([paths.base_dir,'Results/GLM_RMSE.csv'],'w');

% Write header information

header_line = 'RMSE';

for param_i = 1:length(params)
    header_line = [header_line, ', ',char(params{param_i}{1})];
end

fprintf(fid,'%s \n', header_line);

fclose(fid);                                      % Close the file.


% Create .csv files.
fid_Epi = fopen([paths.base_dir,'Results/GLM_Epi_TimeSeries.csv'],'w');
fid_Hyp = fopen([paths.base_dir,'Results/GLM_Hyp_TimeSeries.csv'],'w');
fid_ThermoD = fopen([paths.base_dir,'Results/GLM_ThermoD_TimeSeries.csv'],'w');

% Write header information
format_line = '%f';
for ii = 1:length(fitparams.temp.sim_data.time)-1;
    format_line = [format_line,', %f '];
end
format_line = [format_line,'\n'];

fprintf(fid_Epi,format_line,fitparams.temp.sim_data.time);
fprintf(fid_Hyp,format_line,fitparams.temp.sim_data.time);
fprintf(fid_ThermoD,format_line,fitparams.temp.sim_data.time);

fclose(fid_Epi);                                      % Close the file.
fclose(fid_Hyp);                                      % Close the file.
fclose(fid_ThermoD);                                  % Close the file.


%MCMC---------------------------------------------------------------------%

%Set model and parameter bounds for MCMC model
model.N = length(fit_params_init.(conf.config.varname).time) * length(fit_params_init.(conf.config.varname).depth);
model.ssfun = @runGLMRMSE;
model.modelfun = @runGLMRMSE;

%Set parameter bounds as +/- 50% of initial value
for param_i = 1:length(params)
    params{param_i}{3} = 0.5*params{param_i}{2};
    params{param_i}{4} = 1.5*params{param_i}{2};
end


%First generate an initial chain.

options.nsimu = conf.config.nsimu_ini;
[results, chain, s2chain]= mcmcrun(model,fld_data,params,options,paths);

figure
mcmcplot(chain,[],results,'pairs');


%Then re-run starting from the results of the previous run

options.nsimu =  conf.config.nsimu_full;
[results, chain, s2chain] = mcmcrun(model,fld_data,params,options, paths,results);

%Chain plots should reveal that the chain has converged and we can use the results for estimation and predictive inference.

figure
mcmcplot(chain,[],results,'pairs');



figure
mcmcplot(chain,[],results,'denspanel',2);




%Run model with mean parameter values
RMSE_opt = runGLMRMSE(results.mean,fld_data,params,paths);

%Rename optimal run
movefile([paths.base_dir,'Output/output_new.nc'] ,[paths.base_dir,'Output/output_opt.nc'])

%Plot optimal run - save results
plotLake
xlim([sim_start sim_stop])
ylim([0 max_depth_plots])
fig_name = [paths.base_dir,'Results/Plots_Opt/Sim_Temp_Opt','.png'];
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
set(gcf,'paperposition',[0.1  0.1 15 8]);
print(gcf,'-dpng',fig_name,'-opengl');


%Determine measures of model fit for the optimal plot run and plot
error_final = calcGLMModelFit(fld_data,[paths.base_dir,'Output/output_opt.nc'],paths.varname,'true',paths,'Plots_Opt/');

%Renames Plots folder to Opt_Plots folder
%copyfile([paths.base_dir,'Results/Plots'],[paths.base_dir,'Results/Plots_Opt'])


close all;
%PLOT UNCERTAINTY------------------------------------------------------------%

%We sample 500 parameter realizations from chain and s2chain and calculate the predictive plots.

out = mcmcpred(results,chain,s2chain,data.time,model.modelfun,paths);
out.ylabels = [{'Date'},'Epilimnion Temp (^oC)','Hypolimnion Temp (^oC)','Thermocline Depth (m)'];

% figure
mcmcpredplot(out);
% add the 'y' observations to the plot
obs.ydata(:,1) = fitparams.temp.time;
obs.ydata(:,2) = fitparams.temp.obs_data.epi;
obs.ydata(:,3) = fitparams.temp.obs_data.hyp;
obs.ydata(:,4) = fitparams.temp.obs_data.thermoD;

hold on
for i=1:3
  subplot(3,1,i)
  hold on
  plot(obs.ydata(:,1),obs.ydata(:,i+1),'s');
  ylabel(''); title(out.ylabels(i+1));
  xtik = get(gca,'XTick');
  set(gca,'XTick',xtik,'XTickLabel',[]);
  
  xrange = min(xtik):(max(xtik) - min(xtik)) / 5: max(xtik);
  set(gca,'XTick',xrange,'XTickLabel',datestr(xrange,'mm-yy'));
  hold off
end
axis ij
xlabel('Date');


fig_name = [paths.base_dir,'Results/mcmc_pred','.png'];
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
set(gcf,'paperposition',[0.1  0.1 15 15]);
print(gcf,'-dpng',fig_name,'-opengl');

close


%SAVE AND FINISH ---------------------------------------------------------%

%Save results of MCMC run
mcmc.results = results;
mcmc.chain = chain;
mcmc.s2chain = s2chain;

save([paths.base_dir,'mcmc_chain_',date,'.mat'],'chain','-mat');




%Display time message
runTime     = toc;                %stop counting run time
hours       = runTime / 3600;     %convert runTime from seconds to hours
timeMessage = ['Total Run Time = ', num2str(hours), ' hours'];
disp(timeMessage)


close all;
close;

 end

