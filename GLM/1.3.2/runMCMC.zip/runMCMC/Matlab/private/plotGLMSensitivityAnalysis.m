function MLCPsens_anal = plotGLMSensitivityAnalysis%(LakeNames,MetricNames)%,ParamNames)
%function plotGLMSensitivityAnalysis(LakeNames)
%
% Inputs:
%      LakeNames:  Array of strings corresponding to each of the lakes used
%      in the MLCP sensitivity analysis
%      MetricNames:  Names of Lake Metrics to plot sensitivity to
%      ParamNames: List of parameters used in the sensitivity analysis
%
% Outputs:
%      MLCPsens_anal: MATLAB structure containing percent average error
%      (PRE) for each of the lakes listed in LakeNames for each of the
%      parameters listed in ParamNames.
%
% Uses:
%      plot.m
%
% Written by L. Bruce 19 August 2013
%
% Plots results of runGLMSensitivity.
% Takes the PRE's of each parameter to calculate a probability distribution

ParamNames = [{'coef_mix_conv'},{'coef_wind_stir'},{'coef_mix_shear'}, ...      
    {'coef_mix_turb'},{'coef_mix_KH'},{'coef_mix_hyp'}, ...
    {'ce'},{'ch'},{'coef_wind_drag'}];

MetricNames = {'all','epi','hyp','thermoD','St'};

LakeNames = {'Ammersee','Blelham','Esthwaite','Kinneret03','Kinneret97','MtBold','Pusiano','Stechlin','Zurich03'};

numLakes = length(LakeNames);
numMetrics = length(MetricNames);
numParams = length(ParamNames);

%Loop through lakes and read PRE values for each parameter
for lake_i = 1:numLakes
    %filename = [LakeNames{lake_i},'/Sensitivity/GLM_sensitivity.csv']
    filename = 'GLM_sensitivity.csv'
    sens_data = importdata(filename,',',2);
    param_list = regexprep(regexp(char(sens_data.textdata(1,1)),',','split'),' ','');
    for metric_i = 1:numMetrics
        row_num = find(strcmp(sens_data.textdata(:,1),['PRE_',MetricNames{metric_i}])) - 2;
        PRE_init(lake_i,metric_i) = sens_data.data(row_num,1);
        for param_i = 1:numParams
            col_num = find(strcmp(param_list,ParamNames{param_i}));
            PRE_lower(lake_i,metric_i,param_i) = sens_data.data(row_num,col_num-1);
            PRE_upper(lake_i,metric_i,param_i) = sens_data.data(row_num,col_num);
        end
    end
end

%Loop through metrics then parameters and plot lower, initial and upper probabilities
num_col = 3;
num_row = ceil(numParams/num_col);

for metric_i = 1:numMetrics
    figure
    for param_i = 1:numParams
        subplot(num_col,num_row,param_i)
        bar([1-abs(mean(PRE_lower(:,metric_i,param_i)))/100,...
            1-abs(mean(PRE_init(:,metric_i)))/100,...
            1-abs(mean(PRE_upper(:,metric_i,param_i)))/100]);
        ylim([0.5 1])
        title(ParamNames(param_i))
    end
    text(-5,0.4,MetricNames(metric_i),'FontSize',12)
end

%Save PRE data to return
MLCPsens_anal.PRE_init = PRE_init;
MLCPsens_anal.PRE_lower = PRE_lower;
MLCPsens_anal.PRE_upper = PRE_upper;



