function disp_message(filename)

fid = fopen(filename,'rt');

tline = fgetl(fid);
while tline ~= -1
    disp(tline);
    tline = fgetl(fid);
end
fclose(fid);