%Used Matlab routine lsqnonlin to determine best fit parameters to
%minimise a set of data points y(1:ndata) which is the difference
%between a set of predicted (p) and observed (o) data divided by the 
%standard error (calculated for the mean) for a DYRESM/CAEDYM run of Mono Lake 1991.

%The program returns current best-fit values for the parameters x(1:parno)
%using the Levenberg-Marquardt method of optimisation

clear all
close all
tic;                             %start counting run time

%First read in a dummy LM parameter file with values of -999 entered for the
%n parameters (parno) to be adjusted in the LM methods.

dummydatfile=fopen('../060105/optim_dummy.dat');
orgdatfile=fopen('../060105/mono11_5down.dat');
lineno=0; %line number count
parno=0; %parameter number count
while 1
    dline = fgetl(dummydatfile);
    pline = fgetl(orgdatfile);
    if ~ischar(dline), break, end
    lineno=lineno+1;
    if ~isempty(findstr(dline,'-999'))
        parno=parno+1;
        parline(parno)=lineno;
        orgparam(parno)=sscanf(pline,'%f');
    end
end
fclose(dummydatfile);
fclose(orgdatfile);
%Number of variables fitted against
nvar = 3;
%for parameters Pmax, INmin, fex, G, PON1max, SdNH4
%lbparam = [5.0 1.0 0.1 1.0 0.05 0.005];
%ubparam = [10.0 4.0 0.5 2.0 0.5 0.1];
%lbparam = orgparam*0.8;
%ubparam = orgparam*1.2;
%lbparam(1:10) = [0.25 3 20 0.007 0.0001 0.02 2.0 5.0 1.0 0.5];
%ubparam(1:10) = [0.35 8 30 0.009 0.0020 0.07 3.0 9.0 10.0 2.5];
%lbparam(11:20) = [0.1 0.5 0.1 -0.004 0.02 0.005 0.02 0.05 0.15 0.0];
%ubparam(11:20) = [1.0 0.9 0.5 -0.013 0.15 0.020 0.20 0.40 0.30 2.0];
%lbparam(21:30) = [1.0 0.5 0.1 0.1 0.7 0.0 0.006 0.1 0.03 0.0];
%ubparam(21:30) = [2.0 1.0 0.3 0.7 1.0 3.0 0.010 0.4 0.07 1.5];
%lbparam(31:40) = [1.0 0.2 0.05 0.05 0.05 0.1e-5 1090 0.005 0.0005 0.0];
%ubparam(31:40) = [2.0 0.4 0.20 0.25 0.40 0.5e-4 1300 0.020 0.0020 1.5];
%lbparam(41:44) = [0.005 0.5 0.005 0.2];
%ubparam(41:44) = [0.020 2.5 0.030 1.5];
lbparam(1:10) = [0.25 3 20 0.007 0.0001 0.02 0.5 3.0 0.02 0.5];
ubparam(1:10) = [0.35 8 30 0.009 0.0020 0.07 2.5 11.0 1.0 0.9];
lbparam(11:20) = [0.1 -0.004 0.02 0.005 0.02 0.05 0.15 0.0 1.0 0.5];
ubparam(11:20) = [0.5 -0.013 0.15 0.020 0.20 0.70 0.30 2.0 2.0 1.0];
lbparam(21:30) = [0.1 0.05 0.7 0.0 0.006 0.1 0.05 0.05 0.0 1.0];
ubparam(21:30) = [0.3 0.7 1.0 3.0 0.010 0.4 0.30 7.0 1.5 2.0];
lbparam(31:40) = [0.2 0.05 0.05 0.05 1.0e-3 1090 0.005 0.0005 0.0 0.005];
ubparam(31:40) = [0.4 0.20 0.25 0.40 5.0e-2 1300 0.020 0.0020 1.5 0.020];
lbparam(41:43) = [0.5 0.005 0.2];
ubparam(41:43) = [2.5 0.100 1.5];
%for parami = 1:length(orgparam)
%    if orgparam(parami) >= 0.0
%        lbparam(parami) = orgparam(parami)*0.8;
%        ubparam(parami) = orgparam(parami)*1.2;
%    else
%        lbparam(parami) = orgparam(parami)*1.2;
%        ubparam(parami) = orgparam(parami)*0.8;
%    end
    
%    if orgparam(parami) > 10.0
%        param_scale(parami) = 1e8;
%    elseif orgparam(parami) > 0.05
%        param_scale(parami) = 1e7;
%    else
%        param_scale(parami) = 1e6;
%    end
%end

param_scale = orgparam/1e-7;
param_scale(find(param_scale==0))=1.0;

orgparam = orgparam./param_scale;
lbparam = lbparam./param_scale;
ubparam = ubparam./param_scale;

%sub_index = [2 3 4 6 8 9 10 11 12 34 35 42]; %for first 100 days
sub_index = [2 6 8 9 16 19 28 29 34 35 42 43];

orgparam_sub = orgparam(sub_index);
lbparam_sub = lbparam(sub_index);
ubparam_sub = ubparam(sub_index);
param_scale_sub = param_scale(sub_index);
%options = optimset('DiffMinChange',1e-4,'LargeScale','off');

[x,resnorm,residual,exitflag,output,lambda] = lsqnonlin(@dycd_opt,orgparam_sub,lbparam_sub,ubparam_sub,[],param_scale_sub,sub_index);

resnorm

%Display time message
runTime     = toc;                %stop counting run time
hours       = runTime / 3600;     %convert runTime from seconds to hours
timeMessage = ['Total Run Time = ', num2str(hours), ' hours'];
disp(timeMessage)

%Save optimum run
[chiopt] = dycd_opt(x,param_scale_sub,sub_index);
cd ../060105
  eval(['! copy monoparam.dat mono11_5down_opt.dat']);
  eval(['! copy DYsim.nc DYsim11_5down_opt.nc']);
cd ../PlotResults