function glm_nml = readGLMparams(params)
%
%This function takes the initial glm.nml from InputFiles and reads the
%parameters relevant to the MCMC optimisation routine
%

%-------------------------------------------------------------------------%
%First take initial glm.nml file from InputFiles and calc parameters----%
%-------------------------------------------------------------------------%
%
%Open GLM name list file
fid = fopen('InputFiles/glm_init.nml','r');


%Loop through line by line until reach parameter then read parameter value
%value

ii=1;
while 1
    isparam = 0;
    tline = fgetl(fid);
    if (tline == -1), break, end %end of nml file
    if isempty(tline)
        continue
    end
    if ~strcmp(tline(1),'!')  %Is not a comment line
         tline_cmp = regexprep(tline,' ','');
         equal_i = strfind(tline_cmp,'=');
         if ~isempty(equal_i) %Is a parameter line
             %Check to see if parameter is included in list of parameters
             for par_i = 1:length(params)
                 if strcmp(params{par_i}{1},tline_cmp(1:equal_i-1));
                     glm_nml.(params{par_i}{1}) = str2num(tline_cmp(equal_i+1:end));
                     isparam = 1;
                 end
             end
         end
    end
    %if parameter line not changed then stay as same
    if ~isparam
        nml.txt{ii} = tline;
    end
    ii = ii+1;
end
fclose(fid);