function nmae = calcGLMNMAE(fld_data,simfile,varname)
% function nmae = calcGLMNMAE(fld_data,simfile,varname)
%
% Inputs:
%       fld_data   : MATLAB data structure containing observed data
%		simfile    : filename of GLM output
%       varname    : variable names to make calculations of model
%       fit parameters fld = name given to field variable, sim =
%       corresponding name given to GLM simulated data
%
% Outputs:
%       nmae = normalised root mean error for observed vs simulated data
%
% Uses:
%      readGLMnetcdf.m
%
% Written by L. Bruce 18 April 2013
% Takes GLM simulated output and compares against field data for
% variable "varname".
% Calculates the following measures of best fit for varname:
%    Normalised mean absolute error (NMAE)

%Create structure of GLM variable
sim_data = readGLMnetcdf(simfile,varname);

%Convert simulated z (height from bottom) to depths (mid point for each
%layer)
sim_data.depth = 0.0*sim_data.z - 999;
for time_i = 1:length(sim_data.time)
    max_depth = sim_data.z(time_i,sim_data.NS(time_i));
    sim_data.depth(time_i,1) = max_depth - (sim_data.z(time_i,1))/2;
    for depth_i = 2:sim_data.NS(time_i)
        sim_data.depth(time_i,depth_i) = max_depth - ...
                        (sim_data.z(time_i,depth_i) + sim_data.z(time_i,depth_i-1))/2;
    end
end

%First determine time array to match field and simulated data
[start_date_sim,start_i_sim] = min(sim_data.time);
[start_date_fld,start_i_fld] = min(fld_data.time);
if (start_date_sim > start_date_fld) %start with sim data
    %find field index to start at
    [~, start_i_fld] = min(abs(start_date_sim - fld_data.time));
    start_date = start_date_sim;
else %start with field data
    start_date = start_date_fld;
end

[end_date_sim,end_i_sim] = max(sim_data.time);
[end_date_fld,end_i_fld] = max(fld_data.time);
if (end_date_sim < end_date_fld) %finish with sim data
    %find field index to finish at
    [~, end_i_fld] = min(abs(end_date_sim - fld_data.time));
    end_date = end_date_sim;
else %finish with field data
    end_date = end_date_fld;
end
    

%Now loop through fld time arrays to get closest match to field data
s_ii = 0;
for ii=start_i_fld:end_i_fld
    s_ii = s_ii + 1;
    [~, sim_i(s_ii)] = min(abs(sim_data.time - fld_data.time(ii)));
end

%For when field data is measured at a higher frequency than the simulated
%data we need to subsample the field data to match the simulated data
%frequency
sim_i_unique = unique(sim_i);
for ii = 1:length(unique(sim_i))
    [~, fld_i_unique(ii)] = min(abs(sim_data.time(sim_i_unique(ii)) - fld_data.time));
end

%Then get simulated data to match field data

obs_data.all = [];
sim_data.all = [];
obs_data.surf = [];
sim_data.surf = [];
obs_data.bot = [];
sim_data.bot = [];

data_i = 1;
for time_i = 1:length(fld_i_unique)
    obs_data.surf(time_i) = fld_data.(varname)(fld_i_unique(time_i),1);
    [~, sim_i_depth] = min(abs(sim_data.depth(sim_i_unique(time_i),:) - fld_data.depth(1)));
    sim_data.surf(time_i) = sim_data.(varname)(sim_i_unique(time_i),sim_i_depth);
    obs_data.bot(time_i) = fld_data.(varname)(fld_i_unique(time_i),end);
    [~, sim_i_depth] = min(abs(sim_data.depth(sim_i_unique(time_i),:) - fld_data.depth(end)));
    sim_data.bot(time_i) = sim_data.(varname)(sim_i_unique(time_i),sim_i_depth);
    for kk = 1:length(fld_data.depth)
        obs_data.all(data_i) = fld_data.(varname)(fld_i_unique(time_i),kk);
        [~, sim_i_depth] = min(abs(sim_data.depth(sim_i_unique(time_i),:) - fld_data.depth(kk)));
        sim_data.all(data_i) = sim_data.(varname)(sim_i_unique(time_i),sim_i_depth);
        %If the difference between observed and simulated depths is <2m
        %then keep data else discard
        if abs(sim_data.depth(sim_i_unique(time_i),sim_i_depth) - fld_data.depth(kk)) < 2
            data_i = data_i + 1;
        end
    end
end
        
    
%Remove any NaN's
obs_data.all = obs_data.all(~isnan(obs_data.all));
sim_data.all = sim_data.all(~isnan(obs_data.all));
obs_data.surf = obs_data.surf(~isnan(obs_data.surf));
sim_data.surf = sim_data.surf(~isnan(obs_data.surf));
obs_data.bot = obs_data.bot(~isnan(obs_data.bot));
sim_data.bot = sim_data.bot(~isnan(obs_data.bot));



   %Calculate NMAE
   nmae = sum(abs(sim_data.all - obs_data.all)) /length(obs_data.all) ...
                                                /mean(obs_data.all);

