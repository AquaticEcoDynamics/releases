function glm_opt = mcmcGLMopt
% function glm_opt = mcmcGLMopt
% Inputs:
%
% Outputs:
%       glm_opt: minimum nmae from mcmc run and corresponding parameters
%
% Uses:
%      
%
% Written by L. Bruce 23 April 2013

%find initial run values
    glm_init = load('mcmc_23160.mat');
    glm_opt.nmae = glm_init.mcmc_run.nmae;
    glm_opt.theta = glm_init.mcmc_run.theta;
%Loop through runs to find minimum nmae and corresponding parameter values
for ii=23161:24427
    ii
    length(glm_opt.theta)
    if ~exist(['mcmc_',num2str(ii),'.mat'])
        continue
    end
    glm = load(['mcmc_',num2str(ii),'.mat']);
    if length(glm.mcmc_run.theta)==10
    if glm.mcmc_run.nmae < glm_opt.nmae
        glm_opt.nmae = glm.mcmc_run.nmae;
        glm_opt.theta = glm.mcmc_run.theta;
    end
    end
end

%Loop through runs to find minimum nmae and corresponding parameter values
for ii=231555:231623
    ii
    if ~exist(['mcmc_',num2str(ii),'.mat'])
        continue
    end
    glm = load(['mcmc_',num2str(ii),'.mat']);
    if glm.mcmc_run.nmae < glm_opt.nmae
        glm_opt.nmae = glm.mcmc_run.nmae;
        glm_opt.theta = glm.mcmc_run.theta;
    end
end

