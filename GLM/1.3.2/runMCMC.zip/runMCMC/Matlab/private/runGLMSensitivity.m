
% function sens_anal = runGLMSensitivity(fld_data,params)
% Inputs:
%       fld_data   : MATLAB data structure containing observed data
%		params     : list of parameters with initial values
%
% Outputs:
%       sens_anal = model sensitivity to measure of model fit for
%                    observed vs simulated data of data subset (eg all, 
%                    surface,  hypolimnion temp, Schmidt stability etc
%
% Uses:
%     runGLMModelFit.m
%
% Written by L. Bruce 22 April 2013
% Runs through a set of physical parameters, adjusting each +/- 20% then
% running GLM and comparing how sensitive measures of model fit are to 
% changes in GLM parameters.
%

%Start by cleaning up
clear all
close all

%Add all necessary files in the currently directory
addpath(genpath(pwd));

%start counting run time
tic;

%Variable name
varname = 'temp';

%Lake name
lakename = 'Kinneret97';

%Information on field data
fld_temp_file = ['Field/',lakename,'_Fld_temp.wtr'];

%List of data subsets to calculate sensitivity to
Data_Subsets = {'all','epi','hyp','thermoD','St'};
%List of measures of model fit
Model_Fit = {'RMSE', 'NSE','r2', 'PRE'};

%Some information for ssh connection
ssh2.host_name = 'aqua';
ssh2.usr_name = 'hydro';
ssh2.password = 'modeller';
ssh2.remote_dir = ['Louise/GLM_MLCP/v1.3.1/',lakename];
ssh2.run_glm = ['cd ',ssh2.remote_dir,'; ./glm'];
ssh2.output_file = [ssh2.remote_dir,'/output.nc'];
ssh2.varname = varname;

%First read in field data
fld_data = readLAwtr(fld_temp_file);

%INITIAL RUN-------------------------------------------------------------%

%List of parameters and their initial values
params = {
    {'coef_mix_conv', 0.2}
    {'coef_wind_stir', 0.23}      
    {'coef_mix_shear', 0.30}       
    {'coef_mix_turb', 0.51}       
    {'coef_mix_KH', 0.30} 
    {'coef_mix_hyp', 0.50} 
    {'ce', 0.0013}
    {'ch', 0.0013}
    {'coef_wind_drag', 0.0013}
    };      

theta_initial = zeros(length(params),1);
for param_i = 1:length(params)
    theta_initial(param_i) = params{param_i}{2};
end

%Calculate GLM model fit parameters using initial run
%And save results
sens_anal.init.fitparams = runGLMModelFit(theta_initial,fld_data,params,ssh2,'init',1);
fit_params_init = sens_anal.init.fitparams;

%Plot initial run and comparison against field - save results
plotLake
xlim([sim_start sim_stop])
ylim([0 max_depth_plots])
fig_name = ['Results/Plots/Sim_Temp','.png'];
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
set(gcf,'paperposition',[0.1  0.1 15 8]);
print(gcf,'-dpng',fig_name,'-opengl');

%Now read in and plot field data
%Plot LDS output
figure
varInformation
x_tick = [sim_start:round((sim_start-sim_stop)/4):sim_stop];
x_tick_date = datestr(x_tick,'dd-mmm-yy');
pcolor(fld_data.time,fld_data.depth,fld_data.temp');
 axis ij
shading interp
 xlabel('Date')
 ylabel('Depth (m)')
set(gca,'XTick',x_tick,'XTickLabel',x_tick_date)
var_lim = varIndex.temp.caxis;
var_title = varIndex.temp.title;
 title(var_title)
 caxis(var_lim)
 colorbar

%Save plot of field temperature into Field file
xlim([sim_start sim_stop])
ylim([0 max_depth_plots])
fig_name = ['Results/Plots/Field_Temp','.png'];
set(gcf, 'PaperPositionMode', 'manual');
set(gcf, 'PaperUnits', 'centimeters');
set(gcf,'paperposition',[0.1  0.1 15 8]);
print(gcf,'-dpng',fig_name,'-opengl');

%Now plot scatter and time series comparisons

fitparams = calcGLMModelFit(fld_data,'Output/output_init.nc','temp','true');


%SENSITIVITY ANALYSIS-----------------------------------------------------%

%Now run through list of parameters and calculate indicators of model fit

%Set parameter bounds as +/- 20% of initial value
for param_i = 1:length(params)
    params{param_i}{3} = 0.8*params{param_i}{2};
    params{param_i}{4} = 1.2*params{param_i}{2};
end

%Loop through paramaeters and determine sensitivity to model performance for each
%parameter


for param_i = 1:length(params)
    %Initialies parameters to initial
    theta_lower = theta_initial;
    theta_upper = theta_initial;
    param_name = params{param_i}{1};
    theta_lower(param_i) = params{param_i}{3};
    theta_upper(param_i) = params{param_i}{4};
    sens_anal.(param_name).fitparams_lower = runGLMModelFit(theta_lower,fld_data,params,ssh2,[param_name,'_lower'],1);
    sens_anal.(param_name).fitparams_upper = runGLMModelFit(theta_upper,fld_data,params,ssh2,[param_name,'_upper'],1);
end

%Determine sensitivity to each parameter for each data set using PRE
for param_i = 1:length(params)
    param_name = params{param_i}{1};
    for ii = 1:length(Data_Subsets)
        sens_anal.(param_name).(Data_Subsets{ii}).sens_lower = ...
            (sens_anal.(param_name).fitparams_lower.(varname).(Data_Subsets{ii}).PRE - ...
                fit_params_init.(varname).(Data_Subsets{ii}).PRE)/0.2;
        sens_anal.(param_name).(Data_Subsets{ii}).sens_upper = ...
            (sens_anal.(param_name).fitparams_upper.(varname).(Data_Subsets{ii}).PRE - ...
                fit_params_init.(varname).(Data_Subsets{ii}).PRE)/0.2;
    end
end


% ------------------------- PRINT RESULTS --------------------------------%

%Print table of lake metrics for each measure of model fit


% Open file
% ---------------------------- DEFINE THE FILE --------------------------- %

% Create .csv file.
fid = fopen('GLM_sensitivity.csv','w');

% Write header information

%Header of parmaeter names
header_line = '           ';
header_line = [header_line, ', Initial'];
for ii = 1:length(params)
    header_line = [header_line,', ',params{ii}{1}, ', '];
end
fprintf(fid,'%s\n', header_line);

%Header of uppers and lowers
header_line = 'Lake_Metric';
header_line = [header_line, ', Initial'];
for ii = 1:length(params)
    header_line = [header_line,', Lower', ', Upper'];
end
fprintf(fid,'%s\n', header_line);

% ---------------------------- STORE THE DATA ---------------------------- %

format_line = '%s, %f';
for ii = 1:length(params)
    format_line = [format_line,', %f , %f'];
end
format_line = [format_line,'\n'];

for fit_i = 1:length(Model_Fit)
    for data_i = 1:length(Data_Subsets)
        name_str = [Model_Fit{fit_i},'_',Data_Subsets{data_i}];
        data_line = fit_params_init.(varname).(Data_Subsets{data_i}).(Model_Fit{fit_i});
        for param_i = 1:length(params)
            data_line = [data_line sens_anal.(params{param_i}{1}).fitparams_lower.(varname).(Data_Subsets{data_i}).(Model_Fit{fit_i}), ...
                                   sens_anal.(params{param_i}{1}).fitparams_upper.(varname).(Data_Subsets{data_i}).(Model_Fit{fit_i})];
        end
        fprintf(fid,format_line,name_str,data_line);
    end
end
%Finish table with sensitivity analysis using slope of percentage relative
%error (PRE)
for data_i = 1:length(Data_Subsets)
    name_str = ['SensAnal_PRE_',Data_Subsets{data_i}];
    data_line = 0.0;
    for param_i = 1:length(params)
        data_line = [data_line sens_anal.(params{param_i}{1}).(Data_Subsets{data_i}).sens_lower, ...
                               sens_anal.(params{param_i}{1}).(Data_Subsets{data_i}).sens_upper];
    end
    fprintf(fid,format_line,name_str,data_line);
end

fclose(fid);                                      % Close the file.


% ------------------------------------------------------------------------ %
%Display time message
runTime     = toc;                %stop counting run time
hours       = runTime / 60;     %convert runTime from seconds to minute
timeMessage = ['Total Run Time = ', num2str(hours), ' minutes'];
disp(timeMessage)

    