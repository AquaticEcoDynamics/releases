%function glm_nml = getGLMsimdates
%
%This function takes the initial glm.nml from InputFiles and determines the
%start and finish date in MATLAB dates to use in xlim for the comparison
%plot of field data
%

%-------------------------------------------------------------------------%
%First take initial glm.nml file from InputFiles and insert parameters----%
%-------------------------------------------------------------------------%
%
%Open GLM name list file
fid = fopen([paths.base_dir,'InputFiles/glm_init.nml'],'r');


%Loop through line by line until reach parameter then insert parameter
%value

ii=1;
while 1
    isparam = 0;
    tline = fgetl(fid);
    if (tline == -1), break, end %end of nml file
    if isempty(tline)
        continue
    end
    if ~strcmp(tline(1),'!')  %Is not a comment line
         tline_cmp = regexprep(tline,' ','');
         equal_i = strfind(tline_cmp,'=');
         if ~isempty(equal_i) %Is a parameter line
             %Check to see if parameter timefmt
             if strcmp('timefmt',tline_cmp(1:equal_i-1))
                 timefmt = str2num(tline_cmp(equal_i+1));
             end
             
             %Check to see if parameter startdate
             if strcmp('start',tline_cmp(1:equal_i-1))
                 sim_start = datenum([tline_cmp(equal_i+2:equal_i+11),' ',tline_cmp(end-8:end-1)]);
             end

             %Check to see if parameter stop date
             if strcmp('stop',tline_cmp(1:equal_i-1))
                 sim_stop = datenum([tline_cmp(equal_i+2:equal_i+11),' ',tline_cmp(end-8:end-1)]);
             end

             %Check to see if parameter num_days
             if strcmp('num_days',tline_cmp(1:equal_i-1))
                 sim_days = str2num(tline_cmp(equal_i+1:end));
             end

         end
    end
    ii = ii+1;
end

%If time format specifies number of days recalculate sim_stop
if timefmt == 3
    sim_stop = sim_start + sim_days;
end
fclose(fid);