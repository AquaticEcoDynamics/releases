function nmae = runGLMNMAE(theta,fld_data,params,ssh2)
% function nmae = runGLMNMAE(theta,fld_data,params,ssh2)
%
% Inputs:
%       fld_data   : MATLAB data structure containing observed data
%		params     : list of parameters for current run
%       ssh2       : variables needed to connect to remote host
%       fit parameters fld = name given to field variable, sim =
%       corresponding name given to GLM simulated data
%
% Outputs:
%       nmae = normalised root mean error for observed vs simulated data
%
% Uses:
%      readGLMnetcdf.m
%
% Written by L. Bruce 22 April 2013
% First takes parameter values and creates a glm.nml
% Then runs the model off remote host to create a simulation file output.nc
% Takes GLM simulated output and compares against field data for
% variable "varname".
% Calculates the following measures of best fit for varname:
%    Normalised mean absolute error (NMAE)

%-------------------------------------------------------------------------%
%First write new glm.nml based on current parameters ---------------------%
%-------------------------------------------------------------------------%
newGLMnml

%-------------------------------------------------------------------------%
%Second copy the new glm.nml,run model from remote host, return output----%
%-------------------------------------------------------------------------%

%Open up connection with remote host
ssh2_conn = ssh2_config(ssh2.host_name,ssh2.usr_name,ssh2.password);

%Copy across new glm.nml file with new parameter set
ssh2_conn = scp_put(ssh2_conn, 'glm_new.nml',ssh2.remote_dir,'InputFiles','glm.nml');


%Run the model with the initial parameter set
ssh2_conn = ssh2_command(ssh2_conn, ssh2.run_glm);
%Copy output file to working directory
ssh2_conn = scp_get(ssh2_conn, ssh2.output_file);
%close connection when done
ssh2_conn = ssh2_close(ssh2_conn); 

%Move output file to the Output directory then analyse model fit for new
%parameters
GLMfile = 'output_new.nc';
movefile('output.nc' ,['Output/',GLMfile])

%-------------------------------------------------------------------------%
%Third return measure of model fit to the Optimisation routine -----------%
%-------------------------------------------------------------------------%
%Determine nmae for the new output file
%At this stage just calibrating against temperature
nmae = calcGLMNMAE(fld_data,['Output/',GLMfile],ssh2.varname)

%-------------------------------------------------------------------------%
%Save results in case of crash -------------------------------------------%
%-------------------------------------------------------------------------%

%tm=clock;
%filename=['mcmc_',num2str(tm(3)),num2str(tm(4)),num2str(tm(5)),'.mat'];
%mcmc_run.theta=theta;
%mcmc_run.nmae = nmae;
%save(filename,'mcmc_run','-mat');