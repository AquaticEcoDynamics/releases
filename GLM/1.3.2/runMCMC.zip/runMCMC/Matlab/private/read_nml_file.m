function data = read_nml_file(filename)

fid = fopen(filename,'rt');

data = [];

EOF=0;
while ~EOF
    tline = fgetl(fid);
    if (tline == -1), break, end %end of nml file
    if isempty(tline)
        continue
    end
    
    if strcmp(tline(1),'&')
        
        isinternal = 1;
        varname = regexprep(tline,'&','');
        while isinternal
            
            tline = fgetl(fid);
            
            if (tline == -1), break, end %end of nml file
            if isempty(tline)
                continue
            else
                if ~strcmp(tline(1),'&')
                    if ~strcmp(tline(1),'!')  %Is not a comment line
                        %tline_cmp = regexprep(tline,' ','');
                        eval(['data.(varname).',tline]);
                    end
                else
                    varname = regexprep(tline,'&','');
                    
                end
            end
        end
    end
end
fclose(fid);