function fitparams = runGLMModelFit(theta,fld_data,params,run_info,out_name,remote)
% function nmae = runGLMModelFit(theta,fld_data,params,run_info,out_name)
%
% Inputs:
%       fld_data   : MATLAB data structure containing observed data
%		params     : list of parameters for current run
%       run_info       : variables needed to connect to remote host
%       out_name   : text used to describe current run
%       fit parameters fld = name given to field variable, sim =
%       corresponding name given to GLM simulated data
%
% Outputs:
%       fitparms = MATLAB data strycture containing all model fit
%       parameters comparing simulated to field
%
% Uses:
%      readGLMnetcdf.m
%
% Written by L. Bruce 15 August 2013
% First takes parameter values and creates a glm.nml
% Then runs the model off remote host to create a simulation file output.nc
% Takes GLM simulated output and compares against field data for
% variable "varname".
% Calculates the following measures of best fit for varname:
%    Sample size for observed data (N)
%    Mean of observed data (mean)
%    Variance for observed data (var)
%    Normalised mean absolute error (NMAE)
%    Root square mean error (RSME)
%    Normalised mean error (NME)
%    Percent relative error (PRE)
%    Normalised root square mean error (NRSME)
%    Nash-Sutcliffe Model Efficiency (NSE)
%    Correlation coefficient (r), offsett and slope
%  Saves results to .csv file

%First establish if using remote host to run GLM
if nargin < 6
    remote = 0;
end

%Name of output.nc file to save sim file to
GLMfile = ['output_',out_name,'.nc'];

%-------------------------------------------------------------------------%
%First write new glm.nml based on current parameters ---------------------%
%-------------------------------------------------------------------------%
newGLMnml

%-------------------------------------------------------------------------%
%                        REMOTE CONNECTION                                %
%-------------------------------------------------------------------------%

   %-------------------------------------------------------------------------%
   %Second copy the new glm.nml to sim folder, run model, return output------%
   %-------------------------------------------------------------------------%

   %Copy across new glm.nml file with new parameter set
   movefile([run_info.base_dir,'InputFiles/glm_new.nml'],[run_info.base_dir,'sim/glm.nml']);

   %Run the model
   oldpth=pwd; 
   cd([run_info.base_dir,run_info.sim_dir]) 
   eval(['!',run_info.run_glm]) 
   cd(oldpth) 
   %Move output file to the Output directory then analyse model fit for new
   %parameters
   movefile([run_info.base_dir,'sim/output.nc'] ,[run_info.base_dir,'Output/',GLMfile]);


%-------------------------------------------------------------------------%
%Third return measure of model fit to the Optimisation routine -----------%
%-------------------------------------------------------------------------%
%Determine nmae for the new output file
%At this stage just calibrating against temperature
fitparams = calcGLMModelFit(fld_data,[run_info.base_dir,'Output/',GLMfile],run_info.varname,'false',run_info,[]);

%-------------------------------------------------------------------------%
%Save results ------------------------------------------------------------%
%-------------------------------------------------------------------------%

%movefile('GLM_fitparams.csv',[run_info.base_dir,'Results/GLM_fitparams_',out_name,'.csv']);