function fld_data = readLAwtr(filename)
% Usage: fld_data = readALwtr(filename)
%
% Inputs:
%		filename     : Lake Analyser field data .wtr file name
%                     
% Outputs:
%       fld_data     : field data structure
%
% Uses: 
%       importdata
%
% Simple script to load field data from a Lake Analyser field data .wtr file.
% 
% 
% Created by Louise Bruce 23/4/2013

%import data from field and bathymetry files
data = importdata(filename);
bathdata = importdata([filename(1:end-9) '.bth']);

%Get bathymetry data
fld_data.bthD   = bathdata.data(:,1)';
fld_data.bthA   = bathdata.data(:,2)';


%First text data column is time
fld_data.time = datenum(char(data.textdata{2:end,1}));

%Depth from surface level
fld_data.depth = str2num(char(regexprep(data.textdata(1,2:end),'temp','')));

%Temperarure matix
fld_data.temp = data.data;

%Plot LDS output
%Determine x tick marks
xmin = min(fld_data.time);
xmax = max(fld_data.time);
%xmin = datenum('01-Jan-97');
%xmax = datenum('29-Sep-01');
x_lim = [xmin xmax];
x_tick = [xmin:round((xmax-xmin)/4):xmax];
x_tick_date = datestr(x_tick,'dd-mmm-yy');

figure
varInformation
pcolor(fld_data.time,fld_data.depth,fld_data.temp');
 axis ij
shading interp
 xlabel('Date')
 ylabel('Depth (m)')
 xlim(x_lim)
set(gca,'XTick',x_tick,'XTickLabel',x_tick_date)
var_lim = varIndex.temp.caxis;
var_title = varIndex.temp.title;
 title(var_title)
 caxis(var_lim)
 colorbar