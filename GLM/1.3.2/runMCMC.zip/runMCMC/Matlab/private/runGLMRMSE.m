function RMSE = runGLMRMSE(theta,fld_data,params,run_info,remote)
% function nmae = runGLMRMSE(theta,fld_data,params,run_info,out_name)
%
% Inputs:
%       fld_data   : MATLAB data structure containing observed data
%		params     : list of parameters for current run
%       run_info       : variables needed to connect to remote host
%       out_name   : text used to describe current run
%       fit parameters fld = name given to field variable, sim =
%       corresponding name given to GLM simulated data
%
% Outputs:
%       fitparms = MATLAB data strycture containing all model fit
%       parameters comparing simulated to field
%
% Uses:
%      readGLMnetcdf.m
%
% Written by L. Bruce 26 August 2013
% First takes parameter values and creates a glm.nml
% Then runs the model off remote host to create a simulation file output.nc
% Takes GLM simulated output and compares against field data for
% variable "varname".
% Calculates the following measures of best fit for varname:
%    Root square mean error (RSME)

%First establish if using remote host to run GLM

%-------------------------------------------------------------------------%
%First write new glm.nml based on current parameters ---------------------%
%-------------------------------------------------------------------------%
newGLMnml

%-------------------------------------------------------------------------%
%                        REMOTE CONNECTION                                %
%-------------------------------------------------------------------------%


   %-------------------------------------------------------------------------%
   %Second copy the new glm.nml to sim folder, run model, return output------%
   %-------------------------------------------------------------------------%

   %Copy across new glm.nml file with new parameter set
   movefile([run_info.base_dir,'InputFiles/glm_new.nml'],[run_info.base_dir,'sim/glm.nml']);

   %Run the model
   oldpth=pwd; 
   cd([run_info.base_dir,run_info.sim_dir]) 
   eval(['!',run_info.run_glm]) 
   cd(oldpth)  
   %Move output file to the Output directory then analyse model fit for new
   %parameters
   movefile([run_info.base_dir,'sim/output.nc'] ,[run_info.base_dir,'Output/output_new.nc']);


%-------------------------------------------------------------------------%
%Third return measure of model fit to the Optimisation routine -----------%
%-------------------------------------------------------------------------%
%Determine nmae for the new output file
%At this stage just calibrating against temperature
RMSE = calcGLMRMSE(fld_data,[run_info.base_dir,'Output/output_new.nc'],run_info.varname,theta,run_info);

