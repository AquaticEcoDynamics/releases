function [flowdata] = createGLMinflow(inputfile,outputfile,file_format)
% function [flowdata] = createGLMinflow(inputfile,outputfile,file_format)
%
% Inputs:
%		inputfile    : filename of inflow file to read from
%		outputfile   : filename of inflow file to write to
%       file_format : format of GLM inflow file 1) csv, 2) netcdf
% Outputs
%		flowdata : a matlab structure that contains all the data in the file
%
% Uses:
%      readGLMinflow
%      writeGLMinflow
%      plotGLMinflow
%
% Keywords:  GLM inflow create
%
% Written by L. Bruce 11 October 2011

% Extract data from input file

%Display message
disp(['Converting inflow file: ',inputfile,' to ',outputfile])

%flowdata = readGLMinflow(inputfile,file_format);
flowdata = importdata(inputfile,',',1);

%Convert time to string for output
%flowdata.time = datestr(flowdata.time,29);
flowdata.time = flowdata.textdata(2:end,1);
flowdata.infl_var = flowdata.textdata(1,2:end);
flowdata.inf = flowdata.data;

%Here make any user defined conversions as required

%To convert from ML/day to m3/s
flow_i = find(strcmp(flowdata.infl_var,'flow')) == 1;
flowdata.inf(:,flow_i) = flowdata.inf(:,flow_i)*1000/86400;


%Write inflow data to GLM input file
writeGLMinflow(outputfile,flowdata,file_format)

%Plot GLM inflow file
%plotGLMinflow(outputfile,file_format)
