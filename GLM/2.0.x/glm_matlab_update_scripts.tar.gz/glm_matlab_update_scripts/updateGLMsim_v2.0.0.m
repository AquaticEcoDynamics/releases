%updateGLMsim_v2.0.0
%
% Inputs: LakeName
%
% Outputs:
%
% Uses:
%
%
% Written by L. Bruce 21 February 2015
%
% Updates the working sim directory for a single lake from v1.4.0 to v2.0.0.
% The main changes are glm.nml becomes glm2.nml and inflows and outflows
% converted from ML/day to m3/s.

%Clean up
close all
clear all

%Perform the following:
%   1) Open glm.nml current directory
%   2) Update to glm2.nml
%   3) Save as glm2.nml in current directory
%   4) Rewrite inflow and outflow files conversion from ML/day to m3/s
%   5) Copy new flow files to current directory

    
lakename = 'NameOfYourLake';
    
disp(['Current Lake:  ',LakeName]);
    
%Get GLM data
nml_ini = getGLMnml(glm.nml);
    
%Open GLM name list file
fid = fopen(glm.nml,'r');

    %Loop through line by line until reach parameter then insert parameter
    %value
    ii=1;
    while 1
        isparam = 0;
        tline = fgetl(fid);
        if (tline == -1), break, end %end of nml file
        if isempty(tline)
            continue
        end
        if ~strcmp(tline(1),'!')  %Is not a comment line
             tline_cmp = regexprep(tline,' ','');
             equal_i = strfind(tline_cmp,'=');
             if ~isempty(equal_i) %Is a parameter line
                 %Check to see if parameter is included in list of
                 %parameters to update
                 %1) coef_wind_drag renamed cd
                 if strcmp('coef_wind_drag',tline_cmp(1:equal_i-1));
                     nml.txt{ii} = ['   cd = ',tline_cmp(equal_i+1:end)];
                     isparam = 1;
                 end
                 %3) Coefficient of inflow entrainment moved to inflow
                 %section
                 if strcmp('coef_inf_entrain',tline_cmp(1:equal_i-1));
                     coef_inf_entrain_txt = tline;
                     ii = ii - 1;
                     isparam = 1;
                 end
                 %4) output lake number no longer an option
                 if strcmp('out_lkn',tline_cmp(1:equal_i-1));
                     ii = ii -1;
                     isparam = 1;
                 end
                 %5) Area conversion from 1000m2 to m2 i.e. * 1000
                 if strcmp('A',tline_cmp(1));
                     ii_0 = ii;
                     %Read in original areas
                     tline_cmp=tline_cmp(equal_i+1:end);
                     tline_cmp = regexprep(tline_cmp,' ','');
                     while 1
                         if ii ~= ii_0
                             tline = fgetl(fid);
                             tline_cmp = regexprep(tline,' ','');
                         end
                         if isempty(tline_cmp) || strcmp(tline_cmp(1),'!')
                             continue
                         end
                         Areas = regexp(tline_cmp,',','split');
                         if strcmp(tline_cmp(end),','); Areas = Areas(1:end-1); end
                         if ii == ii_0
                             nml.txt{ii} = '   A = ';
                         else
                             nml.txt{ii} = '       ';
                         end
                        
                         for area_i = 1:length(Areas)
                              nml.txt{ii} = [nml.txt{ii}, num2str(str2num(Areas{area_i})*1000), ',  '];
                         end
                         %If at end of area list break out of while loop
                         %else read next line of areas
                         if ~strcmp(tline_cmp(end),','), break, end %end of areas list
                         ii = ii+1;
                     end
                     %Remove final ',' from last line
                     end_txt = strfind(nml.txt{ii},',');
                     nml.txt{ii} = nml.txt{ii}(1:end_txt(end)-1);
                     isparam = 1;                     
                 end
                 %6) Put a v2 stamp on all inflow file names
                 if strcmp('inflow_fl',tline_cmp(1:equal_i-1));
                     %First line
                     nml.txt{ii} = '   inflow_fl      = ';
                     for inf_i = 1:nml_ini.inf_num_splits(1)
                         nml.txt{ii} = [nml.txt{ii},nml_ini.inflow_files{1,inf_i}(1:end-5),'_v2.csv'', '];
                     end
                     %Subsequent lines
                     for line_i = 2:nml_ini.inf_num_lines
                         fgetl(fid);
                         ii = ii + 1;
                         nml.txt{ii} = '                    ';
                         for inf_i = 1:nml_ini.inf_num_splits(line_i)
                             nml.txt{ii} = [nml.txt{ii},nml_ini.inflow_files{line_i,inf_i}(1:end-5),'_v2.csv'', '];
                         end
                     end
                     %Remove final ',' from last line
                     end_txt = strfind(nml.txt{ii},',');
                     nml.txt{ii} = nml.txt{ii}(1:end_txt(end)-1);

                     isparam = 1;
                 end

                 %7) Put a v2 stamp on all outflow file names
                 if strcmp('outflow_fl',tline_cmp(1:equal_i-1));
                     %First line
                     nml.txt{ii} = '   outflow_fl   = ';
                     for outf_i = 1:nml_ini.outf_num_splits(1)
                         nml.txt{ii} = [nml.txt{ii},nml_ini.outflow_files{1,outf_i}(1:end-5),'_v2.csv'', '];
                     end
                     %Subsequent lines
                     for line_i = 2:nml_ini.outf_num_lines
                         fgetl(fid);
                         ii = ii + 1;
                         nml.txt{ii} = '                  ';
                         for outf_i = 1:nml_ini.outf_num_splits(line_i)
                             nml.txt{ii} = [nml.txt{ii},nml_ini.outflow_files{line_i,inf_i}(1:end-5),'_v2.csv'', '];
                         end
                     end
                     %Remove final ',' from last line
                     end_txt = strfind(nml.txt{ii},',');
                     nml.txt{ii} = nml.txt{ii}(1:end_txt(end)-1);

                     isparam = 1;
                 end

             elseif strcmp('&inflow',tline_cmp);
                 nml.txt{ii} = tline;
                 ii = ii + 1;
                 nml.txt{ii} = coef_inf_entrain_txt;
                 isparam = 1;
             end
        end
        %if parameter line not changed then stay as same
        if ~isparam
            nml.txt{ii} = tline;
        end
        ii = ii+1;
    end
    fclose(fid);

    %-------------------------------------------------------------------------%
    %Write new glm2.nml GLM name list file ------------------------------%
    %-------------------------------------------------------------------------%
    %Open new GLM name list file
    fid = fopen('glm2.nml','w');
    for ii = 1:length(nml.txt)
        fprintf(fid,'%s\n',nml.txt{ii});
    end
    fclose(fid);
    clear nml
    
    %-------------------------------------------------------------------------%
    %Convert inflows from ML/day to m3/s -------------------------------------%
    %-------------------------------------------------------------------------%
    nml = getGLMnml('glm.nml');

    %Get inflow file names
    inf_i = 0;
    for ii = 1:nml.inf_num_lines
        for jj = 1:nml.inf_num_splits(ii)
            inf_i = inf_i + 1;
            inf_files{inf_i} = nml.inflow_files{ii,jj}(2:end-1);
        end
    end
    
    %Convert ML/day to m3/s
    for inf_i = 1:nml.num_inflows
        createGLMinflow(inf_files{inf_i},[inf_files{inf_i}(1:end-4),'_v2.csv'],1);
        close
    end
    
    %-------------------------------------------------------------------------%
    %Convert outflows from ML/day to m3/s ------------------------------------%
    %-------------------------------------------------------------------------%
    
    %Get outflow file names
    outf_i = 0;
    for ii = 1:nml.outf_num_lines
        for jj = 1:nml.outf_num_splits(ii)
            outf_i = outf_i + 1;
            outf_files{outf_i} = nml.outflow_files{ii,jj}(2:end-1);
        end
    end
    
    %Convert ML/day to m3/s
    for outf_i = 1:nml.num_outflows
        createGLMoutflow(outf_files{outf_i},[outf_files{outf_i}(1:end-4),'_v2.csv'],1);
        close
    end
    clear nml
