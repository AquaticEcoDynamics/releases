function [flowdata] = createGLMoutflow(inputfile,outputfile,file_format)
% function [flowdata] = createGLMoutflow(inputfile,outputfile,file_format)
%
% Inputs:
%		inputfile    : filename of outflow file to read from
%		outputfile   : filename of outflow file to write to
%       file_format : format of GLM outflow file 1) csv, 2) netcdf
% Outputs
%		flowdata : a matlab structure that contains all the data in the file
%
% Uses:
%      readGLMoutflow
%      writeGLMoutflow
%      plotGLMoutflow
%
% Keywords:  GLM outflow create
%
% Written by L. Bruce 9 Januarty 2015

% Extract data from input file

%Display message
disp(['Converting outflow file: ',inputfile,' to ',outputfile])

flowdata = importdata(inputfile,',',1);

%Convert time to string for output
flowdata.time = flowdata.textdata(2:end,1);
flowdata.outflow = flowdata.data;

%Here make any user defined conversions as required

%To convert from ML/day to m3/s
flowdata.outflow = flowdata.outflow*1000/86400;


%Write outflow data to GLM input file
writeGLMoutflow(outputfile,flowdata,1,file_format)

%Plot GLM outflow file
%plotGLMoutflow(outputfile)
