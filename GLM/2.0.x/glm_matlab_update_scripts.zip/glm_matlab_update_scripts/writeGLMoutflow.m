function [] = writeGLMoutflow(filename,flowStruct,num_outfl,file_format)
% function [] = writeGLMmet(filename,flowStruct,num_outfl,file_format)
%
% Inputs:
%		filename    : filename of the meteorology file to write to
%		flowStruct  : a matlab structure that contains all the data in the file
%                      usually created in createGLMoutflow
%       num_outfl   : number of outflows
%       file_format : format of GLM meteorological file 1) csv, 2) netcdf
%
% Written by L. Bruce 27 September 2011
%


if file_format == 1

% Open file
% ---------------------------- DEFINE THE FILE --------------------------- %

% Create .csv file.
fod = fopen(filename, 'w');                     

% Write header information
header_line = 'time';
for outi = 1:num_outfl
    %header_line = [header_line,', flow',num2str(outi)];
    header_line = [header_line,', flow'];
end
fprintf(fod,'%s \n', header_line);


% ---------------------------- STORE THE DATA ---------------------------- %

for dayi = 1:length(flowStruct.time)
    flow_line = flowStruct.time{dayi,:};
    for outi = 1:num_outfl;
        flow_line = [flow_line,', ',num2str(flowStruct.outflow(dayi,outi))];
    end
    fprintf(fod,'%s\n',flow_line);
end 

fclose(fod);                                      % Close the file.

% ------------------------------------------------------------------------ %

elseif file_format == 2

    % Open file
% ---------------------------- DEFINE THE FILE --------------------------- %

% Create NetCDF file.
nc = netcdf(filename, 'clobber');                     

% Global attributes.
nc.description = '';       
nc.date = date;

% Define dimensions.
nc('time') = max(size(flowStruct.time)); 

% Define variables and dimensions.
nc{'time'} = {'time'};     


%Define Attributes
nc{'time'}.long_name = 'time' ;
nc{'time'}.units = flowStruct.time_units ;



% ---------------------------- STORE THE DATA ---------------------------- %

nc{'time'}(:) = flowStruct.time;

nc = close(nc);                                      % Close the file.

% ------------------------------------------------------------------------ %
else
    disp(['Error file format ',num2str(file_format),' not valid']);
end %type of output file