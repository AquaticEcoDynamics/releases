#!/bin/bash

export EXTERNAL_LIBS=static
export GOTMDIR=${CURDIR}/../GOTM
export PLOTDIR=${CURDIR}/../libplot

BUILDWHAT=""
ARGLIST=""

while [ $# -gt 0 ] ; do
  case $1 in
    --debug)
      export DEBUG=true
      ARGLIST="$ARGLIST $1"
      ;;
    --fence)
      export FENCE=true
      ARGLIST="$ARGLIST $1"
      ;;
    --single)
      export SINGLE=true
      ARGLIST="$ARGLIST $1"
      ;;
    --plots)
      export PLOTS=true
      ARGLIST="$ARGLIST $1"
      ;;
    --*)
      ARGLIST="$ARGLIST $1"
      ;;
    *)
      BUILDWHAT=$1
      ;;
  esac
  shift
done

if [ "$BUILDWHAT" = "" ] ; then
   BUILDWHAT="glm"
   echo Assuming build glm
fi
echo ARGLIST=\"$ARGLIST\"
exit
export OSTYPE=`uname -s`
if [ "$OSTYPE" == "Darwin" ] ; then
  brew -v >& /dev/null
  if [ $? != 0 ] ; then
    which port >& /dev/null
    if [ $? != 0 ] ; then
      echo no ports and no brew
    else
      export MACPORTS=true
    fi
  else
    export HOMEBREW=true
  fi
fi

case $BUILDWHAT in
  glm)
    cd GLM
    ./build_glm.sh $ARGLIST
    ;;
  tuflowfv)
    cd TUFLOWFV
    ./build_tuflowfv.sh $ARGLIST
    ;;
  libfvaed2)
    cd lidfvaed2
    ./build_libfvaed2.sh $ARGLIST
    ;;
  *)
    echo Unknown build option $BUILDWHAT
    echo valid builds are glm libfvaed2 tuflowfv
    ;;
esac

exit 0
