# GLM Examples

[![DOI](https://zenodo.org/badge/135269961.svg)](https://zenodo.org/badge/latestdoi/135269961)

* Lake Kinneret
* Grosse Dhuen
* Woods Lake
* Ellen Brook Wetland
* Sparkling Lake
