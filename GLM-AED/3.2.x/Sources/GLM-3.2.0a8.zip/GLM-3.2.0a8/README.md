AED_Tools is the prefered starting point for downloading source trees for AED projects. It contains
fetch_sources scripts for Unix based (Linux/Mac) or windows to download or update Source trees for
GLM, libfvaed2 and libaed2. There are also some useful scripts in admin to help track changes.
