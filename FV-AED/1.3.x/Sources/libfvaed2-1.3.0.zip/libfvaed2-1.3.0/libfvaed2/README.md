# libfvaed2

Library that connects a Finite Volume hydrodynamic model to AED2.
