#!/bin/bash

#export DEBUG=true
export SINGLE=true
export EXTERNAL_LIBS=static
export EXTERNAL_LIBS=shared
export FC=ifort

export F77=$FC
export F90=$FC
export F95=$FC

if [ "$SINGLE" = "true" ] ; then
  export PRECISION=1
else
  export PRECISION=2
fi
if [ ! -d lib ] ; then
  mkdir lib
fi
if [ ! -d modules ] ; then
  mkdir modules
fi

make distclean
make
